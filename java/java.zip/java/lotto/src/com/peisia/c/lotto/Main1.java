package com.peisia.c.lotto;

public class Main1 {

	public static void main(String[] args) {
		Lotto1 lotto = new Lotto1();
		lotto.run();
	}

}
