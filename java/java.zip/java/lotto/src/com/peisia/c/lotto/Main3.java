package com.peisia.c.lotto;

public class Main3 {

	public static void main(String[] args) {
		Lotto3 lotto = new Lotto3();
		lotto.run();
	}

}
