package com.peisia.c.lotto;

public class Main2 {

	public static void main(String[] args) {
		Lotto2 lotto = new Lotto2();
		lotto.run();
	}

}
