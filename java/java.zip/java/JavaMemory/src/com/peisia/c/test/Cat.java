package com.peisia.c.test;

public class Cat {

	public int age;

}
