package kioskcom.peisia.c.kiosk;

public class Main {

	public static void main(String[] args) {
		Kiosk k = new Kiosk();
		k.run();
	}
}
