package com.peisia.test;

public class Main {
	public static void main(String[] args) {
		Son son = new Son();
		son.kimchi();
	}
}