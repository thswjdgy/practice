package com.peisia.test;

public class Item extends GameObj {
//	String name;
	
	int weight;
	int 수명;
}
