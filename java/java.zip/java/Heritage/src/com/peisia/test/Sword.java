package com.peisia.test;

public class Sword extends Item {
	int attack;

}
