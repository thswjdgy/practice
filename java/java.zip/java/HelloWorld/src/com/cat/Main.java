package com.cat;
//주석임								
/* 여러줄 주석임 */								
public class Main {		//접근제한자 public . 클래스임을 표시하는 키워드 class. 						
		//클래스이름인 Cat (첫 대문자 주의. 해당 파일이름도 Cat.java 로 똑같아야 함 주의)						
	// 이게 자바의 함수임. 멤버 함수 맞음. 단, 이 main 함수는 특수 함수임.							
	// 이 main 함수부터 코드 실행 흐름이 시작됨.							
	// 각 키워드들은 일단 무시하시고 그냥 복붙해서 쓰거나 main 이라고 타이핑 하고 							
	// ctrl + space 하면 vsc 에밋 기능처럼 코드 자동완성되니 이걸 이용하시오.							
//	main치고 ctrl + space							
								
	public static void main(String[] args) {							
								
		//콘솔창에 출력해주는 함수임. 매개변수에 출력할꺼 넣고						
		//얘도 에밋 기능 있음. sysout 치고 ctrl + space						
		// System.out.println('헬로 키티 월드');			// 문자열을 작은따옴표로 묶는거 안됨. 주의.			
		System.out.println("헬로 키티 월드");		
		// 무조건 큰 따옴표임. 까다로움.			
								
		//실행은 ctrl + f11						
	}							
}							