package com.peisia.c.test;

public class Cat {
	int age;
	String name;
	String hobby;
	
	void x() {
		
	}
	int y() {
		return 100;
	}
	int add(int a, int b) {
		int sum = a + b;
		return sum;
	}
	
	//js
	//생성자 함수 오버로딩
	public Cat() {
		System.out.println("태어나줘서 고마워");
	}
	public Cat(int age, String name, String hobby) {
		this.age = age;
		this.name = name;
		this.hobby = hobby;
		System.out.println("태워나줘서 고마워 귀찮아서 데이터 바로 3개 넣어줬어.");
	}
	public Cat(int age, String name) {
		this.age = age;
		this.name = name;
		System.out.println("태어나줘서 고마워! 귀찮아서 데이터 바로 2개 넣어줬어.");
	}
	
}
