package com.peisia.c.test.util;

import com.peisia.c.test.util.Dice;

public class Main {
	
	public static void main(String[] args) {
		
		
//	int r = (int) (Math.random() * 6+1);
		
//		Dice x = new Dice();
//		int r = x.roll(4);
		
		int r = Dice.roll(6);
		
		System.out.println("주사위를 굴려 " + r + " 이 나왔습니다.");
	}

}
