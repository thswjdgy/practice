package com.peisia.c.rps;

public class Xxx {
	public static void main(String[] args) {
		Rps r = new Rps();
		r.run();
	}
}